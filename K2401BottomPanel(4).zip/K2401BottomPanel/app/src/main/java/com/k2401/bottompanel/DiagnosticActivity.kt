package com.k2401.bottompanel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.TextView

class DiagnosticActivity : Activity() {

    private lateinit var tv: TextView
    private var immersiveOn = false
    private var report = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostic)
        tv = findViewById(R.id.tvDiag)

        // Edge-to-edge request: if the system grants full height, we want it now
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }

        window.decorView.setOnApplyWindowInsetsListener { _, insets ->
            renderReport(insets)
            insets
        }
        window.decorView.post { renderReport(null) }

        findViewById<Button>(R.id.btnImmersive).setOnClickListener { toggleImmersive() }
        findViewById<Button>(R.id.btnOverlayTest).setOnClickListener {
            startService(Intent(this, PanelOverlayService::class.java)
                .setAction(PanelOverlayService.ACTION_TEST_REGION))
        }
        findViewById<Button>(R.id.btnShare).setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, report.toString())
            }
            startActivity(Intent.createChooser(send, "Send diagnostic report"))
        }
    }

    @SuppressLint("SetTextI18n")
    private fun renderReport(insets: WindowInsets?) {
        val sb = StringBuilder()
        fun line(k: String, v: Any?) { sb.append("$k: $v\n"); }

        line("Build.MODEL", Build.MODEL)
        line("Build.DISPLAY (firmware)", Build.DISPLAY)
        line("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")

        // 1. Physical display
        val disp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            display else @Suppress("DEPRECATION") windowManager.defaultDisplay
        val real = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            @Suppress("DEPRECATION") disp?.getRealSize(real)
        val realM = android.util.DisplayMetrics()
        @Suppress("DEPRECATION") disp?.getRealMetrics(realM)
        line("Physical display (getRealSize)", "${real.x} x ${real.y}")
        line("Physical display (getRealMetrics)", "${realM.widthPixels} x ${realM.heightPixels}")

        // 2. App-usable metrics
        val appM = resources.displayMetrics
        line("App metrics (Resources)", "${appM.widthPixels} x ${appM.heightPixels}  dp=${appM.widthPixels / appM.density}x${appM.heightPixels / appM.density}")

        // 3. Root view
        val root = window.decorView.rootView
        line("Root view size", "${root.width} x ${root.height}")

        // 4. Insets / cutout
        val wi = insets ?: root.rootWindowInsets
        if (wi != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val se = wi.getInsetsIgnoringVisibility(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                line("Insets bottom (system+cutout, ignore visibility)", se.bottom)
                line("Insets top", se.top)
                line("Cutout", wi.displayCutout?.safeInsetBottom ?: "none")
            } else {
                @Suppress("DEPRECATION")
                line("systemWindowInsetBottom", wi.systemWindowInsetBottom)
                @Suppress("DEPRECATION")
                line("stableInsetBottom", wi.stableInsetBottom)
                @Suppress("DEPRECATION")
                line("Cutout", wi.displayCutout?.safeInsetBottom ?: "none")
            }
        } else line("Insets", "not available yet")

        // 5. Immersive state
        @Suppress("DEPRECATION")
        val vis = window.decorView.systemUiVisibility
        line("Immersive sticky active",
            (vis and View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY) != 0)

        // 6. Forced display size (vendor trick that reserves screen strips)
        val cr = contentResolver
        line("display_size_forced", Settings.Global.getString(cr, "display_size_forced") ?: "(unset)")
        line("display_density_forced", Settings.Global.getString(cr, "display_density_forced") ?: "(unset)")
        line("policy_control", Settings.Global.getString(cr, "policy_control") ?: "(unset)")

        // 7. Verdict hint
        val appH = appM.heightPixels
        val blackPx = realM.heightPixels - appH
        sb.append("\n---- VERDICT ----\n")
        if (realM.heightPixels == appH && (wi == null || getBottomInset(wi) == 0)) {
            sb.append("App window reaches the physical bottom. Region should be drawable.\n")
        } else if (!Settings.Global.getString(cr, "display_size_forced").isNullOrEmpty()) {
            sb.append("!!! display_size_forced is SET. The firmware shrank the logical display. " +
                    "The black strip is outside every app window. A normal APK cannot draw there.\n")
        } else if (blackPx > 0) {
            sb.append("App window ends $blackPx px above the physical bottom: " +
                    "that strip is reserved by the system/firmware (privileged surface). " +
                    "Third-party apps cannot draw there.\n")
        } else {
            sb.append("Bottom inset present but no missing pixels: immersive mode may reclaim it. " +
                    "Run the immersive test.\n")
        }
        sb.append("\nRed band test: the red strip below is INSIDE this app window. " +
                "If your physical screen stays BLACK below this app's bottom edge, " +
                "the region is firmware-reserved — no APK can fix it.")

        tv.text = sb.toString()
        report = sb
    }

    private fun getBottomInset(wi: WindowInsets): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            wi.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars()).bottom
        } else {
            @Suppress("DEPRECATION") wi.systemWindowInsetBottom
        }
    }

    @Suppress("DEPRECATION")
    private fun toggleImmersive() {
        immersiveOn = !immersiveOn
        window.decorView.systemUiVisibility = if (immersiveOn)
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        else View.SYSTEM_UI_FLAG_VISIBLE
        window.decorView.postDelayed({ renderReport(null) }, 400)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.postDelayed({ renderReport(null) }, 300)
    }
}
