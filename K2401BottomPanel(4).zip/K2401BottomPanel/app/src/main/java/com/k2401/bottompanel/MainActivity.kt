package com.k2401.bottompanel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnDiag).setOnClickListener {
            startActivity(Intent(this, DiagnosticActivity::class.java))
        }
        findViewById<Button>(R.id.btnPerm).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnShow).setOnClickListener {
            startForegroundServiceCompat(Intent(this, PanelOverlayService::class.java)
                .setAction(PanelOverlayService.ACTION_SHOW))
        }
        findViewById<Button>(R.id.btnHide).setOnClickListener {
            startService(Intent(this, PanelOverlayService::class.java)
                .setAction(PanelOverlayService.ACTION_HIDE))
        }

        val sb = findViewById<SeekBar>(R.id.sbHeight)
        val tvH = findViewById<TextView>(R.id.tvHeight)
        val prefs = getSharedPreferences(PanelOverlayService.PREFS, Context.MODE_PRIVATE)
        sb.progress = prefs.getInt(PanelOverlayService.KEY_HEIGHT_DP, 90)
        tvH.text = "${sb.progress} dp"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                tvH.text = "$p dp"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                prefs.edit().putInt(PanelOverlayService.KEY_HEIGHT_DP, s!!.progress).apply()
                startService(Intent(this@MainActivity, PanelOverlayService::class.java)
                    .setAction(PanelOverlayService.ACTION_SHOW))
            }
        })

        updateStatus()
    }

    private fun startForegroundServiceCompat(i: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
    }

    override fun onResume() { super.onResume(); updateStatus() }

    private fun updateStatus() {
        val st = findViewById<TextView>(R.id.tvStatus)
        st.text = buildString {
            append("Overlay permission: ")
            append(if (Settings.canDrawOverlays(this@MainActivity)) "GRANTED" else "NOT granted")
            append("\nAutostart after boot: registered (works if battery opt-out allows)")
            append("\n\nIMPORTANT: run Diagnostics first. If the report says the " +
                    "region is firmware-reserved, no overlay can paint there.")
        }
    }
}
