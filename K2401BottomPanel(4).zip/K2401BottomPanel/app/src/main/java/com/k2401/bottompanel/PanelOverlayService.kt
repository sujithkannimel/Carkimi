package com.k2401.bottompanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.Toast

class PanelOverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.k2401.bottompanel.SHOW"
        const val ACTION_HIDE = "com.k2401.bottompanel.HIDE"
        const val ACTION_TEST_REGION = "com.k2401.bottompanel.TEST_REGION"
        const val PREFS = "panel_prefs"
        const val KEY_HEIGHT_DP = "height_dp"
        private const val CHANNEL_ID = "panel_service"
        private const val NOTIF_ID = 42
    }

    private var panelView: View? = null
    private var testView: View? = null
    private val handler = Handler(Looper.getMainLooper())

    private val wm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    private fun heightDp(): Int =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_HEIGHT_DP, 90)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> removePanel()
            ACTION_TEST_REGION -> runRegionTest()
            else -> showPanel()
        }
        return START_STICKY
    }

    private fun showPanel() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission not granted", Toast.LENGTH_LONG).show()
            return
        }
        removePanel()

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, dp(heightDp()),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL }

        val v = LayoutInflater.from(this).inflate(R.layout.panel_layout, null)
        v.findViewById<ImageButton>(R.id.btnHome).setOnClickListener {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        v.findViewById<ImageButton>(R.id.btnApps).setOnClickListener {
            // No standard app-drawer intent on Android; try the common AOSP action first
            val drawer = Intent("android.intent.action.ALL_APPS")
            if (drawer.resolveActivity(packageManager) != null)
                startActivity(drawer.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else startActivity(Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        v.findViewById<ImageButton>(R.id.btnMaps).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW,
                android.net.Uri.parse("geo:0,0?q="))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        v.findViewById<ImageButton>(R.id.btnPhone).setOnClickListener {
            startActivity(Intent(Intent.ACTION_DIAL)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        v.findViewById<ImageButton>(R.id.btnHidePanel).setOnClickListener {
            removePanel()
            handler.postDelayed({ showPanel() }, 15_000)  // auto-restore
        }
        panelView = v
        try { wm.addView(v, params) } catch (e: Exception) {
            Toast.makeText(this, "Overlay failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removePanel() {
        panelView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panelView = null
    }

    /** Diagnostic: paint a bright strip in the bottom 180 px of the screen via overlay.
     *  If the physical screen shows it, the region is reachable. If it stays black,
     *  nothing a third-party app draws can appear there. */
    private fun runRegionTest() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_LONG).show()
            return
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val v = View(this).apply {
            setBackgroundColor(Color.parseColor("#FF1744"))
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, dp(180),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL }
        try {
            wm.addView(v, params)
            testView = v
            Toast.makeText(this,
                "RED STRIP TEST: look at the bottom of the screen for 8 seconds…",
                Toast.LENGTH_LONG).show()
            handler.postDelayed({ removeTest() }, 8_000)
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeTest() {
        testView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        testView = null
    }

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_ID, "Bottom panel", NotificationManager.IMPORTANCE_LOW))
    }

    private fun pi(action: String): PendingIntent = PendingIntent.getService(
        this, action.hashCode(),
        Intent(this, PanelOverlayService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("K2401 Bottom Panel active")
            .setContentText("Tap to configure · Panel stays over the launcher")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(
                null, "Hide 30s", pi(ACTION_HIDE)).build())
            .addAction(Notification.Action.Builder(
                null, "Show", pi(ACTION_SHOW)).build())
            .setOngoing(true)
            .build()
    }
}
