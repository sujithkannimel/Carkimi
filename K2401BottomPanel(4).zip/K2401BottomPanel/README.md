# K2401 Bottom Panel - build the APK from your phone (no PC)

## What you have
A ZIP of Android source code. It is NOT an app yet. Follow the steps below to
turn it into a real installable APK using only your phone's browser.

## Step-by-step (10-15 minutes, phone only)

1. **Download** `K2401BottomPanel.zip` to your phone (from this chat) and
   remember where it saved (usually Downloads/).

2. **Create a free GitHub account** in your phone browser: https://github.com
   Sign up with email.

3. **Create a repository** (tap + -> New repository), name it e.g. `k2401`,
   keep it Public, tap Create. (Skip "Add a README".)

4. **Upload the ZIP**: In the new repo tap "Add file" -> "Upload files" ->
   "choose your files" -> pick `K2401BottomPanel.zip` from Downloads ->
   tap "Commit changes". The zip must sit at the TOP level of the repo,
   named exactly `K2401BottomPanel.zip`.

5. **Create the build script file**: Tap "Add file" -> "Create new file".
   In the "Name your file" box type exactly:
       .github/workflows/build-apk.yml
   (GitHub creates the folders automatically when you type slashes.)
   Then open the file `build-apk.yml` from this project in a text viewer,
   copy its FULL contents, paste into the GitHub editor, and tap
   "Commit changes". (The file is short - about 30 lines.)

6. **Run the build**: Tap the "Actions" tab at the top of the repo ->
   "Build APK" on the left -> "Run workflow" button (right side) -> Run.
   The build takes 5-10 minutes. A green checkmark = success.

7. **Download the APK**: Open the finished run (tap its title), scroll to
   "Artifacts", tap `K2401-diagnostic-and-panel-APK` to download.
   That is a ZIP containing `app-debug.apk`.

8. **Install on the head unit**: Copy `app-debug.apk` to a USB stick (or
   transfer it by Bluetooth / "Files" app / Quick Share to the unit if it
   is online), open it with the unit's file manager, allow "Install unknown
   apps" when asked, and install.

## What the app does
- "1. Run display diagnostics" -> full report + on-screen red-band test +
  overlay red-strip test. Send/share me the text of the report.
- "2. Grant overlay permission" -> one-time system permission.
- "3. Show bottom panel" -> the replacement ribbon (Home / Apps / clock /
  date / Maps / Phone). Height adjustable with the slider.
- Auto-starts after boot; hide for 15 s via the x button or notification.

## If GitHub is blocked/unusable where you are
Ask a friend with any PC for 10 minutes: install Android Studio (free),
open this project folder, Build > Build APK, and send you the APK via
WhatsApp/Line/Quick Share. That is the only other realistic path - there is
no safe website that compiles Android projects for you.
